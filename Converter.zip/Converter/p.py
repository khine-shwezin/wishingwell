import xlwt
import json
import ast
import xlrd
import os

from xlwt import Workbook
print("Starting.....")

def handleBlock(wb, k,mainD):
    rNum = 1
    s1 = wb.add_sheet(k)
    for subInfo in mainD:
      colNum = 1
      keyList = []

      for k in subInfo:
        sK = str(k).encode('utf-8').strip()
        keyList.append(k)
        if k == 'type80211':
          da = ""
          for a in subInfo[k].keys():
              da = da+" "+ a.encode('utf-8') +" "
          s1.write(rNum,colNum,da)
        elif type(subInfo[k]) == unicode:
          sV = subInfo[k].encode('utf-8')
          s1.write(rNum,colNum,subInfo[k])
        else:
          sV = str(subInfo[k])
          s1.write(rNum,colNum, sV.encode('utf-8').strip())
        colNum = colNum + 1
      rNum = rNum + 1
    c = 1
    for k in keyList:
      s1.write(0,c,k)
      c = c+1
    return 1

def createSheet(wb, filePath, fileName):
    f = open(filePath, "r")
    data = ""
    rawD = ""
    text = ""
    lV = []
    rNum = 1
    for x in f:
     data = x
    j = json.dumps(data)
    j = json.loads(j).encode('utf-8').strip()
    mainD = json.loads(j)
    for k in mainD:
      rawD =rawD + "\n ---- Key Below----\n"+  str(k) + "\n---  Start  ---\n"+ str(mainD[k])+"\n++++    END    ++++\n\n"
      if k=='ssids':
        m = mainD[k]
        done = handleBlock(wb, k, m)
      if k=='aps':
        m = mainD[k]
        done = handleBlock(wb, k, m)
      if k=='stations':
        m = mainD[k]
        done = handleBlock(wb, k, m)
      if k=='channels':
        m = mainD[k]
        done = handleBlock(wb, k, m)
    raw = open("raw.txt", "w")
    raw.write(rawD)
    raw.close()
    f2 = open("note.txt", "w")
    f2.write(text)
    f2.close()
    outputDir = "output/"
    fName =  outputDir + fileName+".xls"
    wb.save(fName)
    print("Completed! Check "+fName)

inputDir = "./input"
entries = os.listdir(inputDir)
for entry in entries:
  if "." in entry:
    ext = entry.split(".")[1]
    if (ext == "acsx"):
      fName = entry.split(".")[0]
      filePath = inputDir+"/"+entry
      wb = Workbook()
      createSheet(wb, filePath, fName)

'''
----------------------  READ ME ----------------------  
$python p.py
------------------------------------------------------

p.py to convert acsx file into excel sheet. p.py takes all acsx files placed in input folder, parses , converts and generates the output files with respective file names in the form of excel sheets. 

How to run in Ubuntu Machine
1) Place the input files into Home > Converter > Input folder.
1) Open Terminal. You should be in HOME already
2) Go to Converter folder
   	$cd Converter
3) Run  p.py
	$python p.py
4) Check the output files in Output folder

Note:
Into excel workbook, p.py will parse only acsx files 
If you need to run this file in other ubuntu machine, you need to install followings
	1) sudo apt-get install python
	2) pip install xlrd
	3) pip install xlwt
'''
      

