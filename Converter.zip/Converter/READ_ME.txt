
----------------------  READ ME ----------------------  
$python p.py
------------------------------------------------------

p.py to convert acsx file into excel sheet. p.py takes all acsx files placed in input folder, parses , converts and generates the output files with respective file names in the form of excel sheets. 

------------------------------------------------------
How to run in Ubuntu Machine
------------------------------------------------------
1) Place the input files into Home > Converter > Input folder.
2) Open Terminal. You should be in HOME already
3) Go to Converter folder
   	$cd Converter
4) Run  p.py
	$python p.py
5) Check the output files in Output folder

Note:
Into excel workbook, p.py will parse only acsx files 
If you need to run this file in other ubuntu machine, you need to install followings
	1) sudo apt-get install python
	2) pip install xlrd
	3) pip install xlwt
	

------------------------------------------------------
How to Run in Windows 10 > Ubuntu
------------------------------------------------------
The location of Ubuntu's root in Windows 10 is C:\Users\test\AppData\Local\Packages\CanonicalGroupLimited.UbuntuonWindows_79rhkp1fndgsc\LocalState\rootfs\home\me\
1) Place your acsx files into input folder under Converter folder.
2) Launch Ubuntu in Windows 10. You should be in 'me' account.
3) change the permission values on Converter folder. If sudo password is asked, type 'me123'
	$sudo chmod -R 777 Converter
3) Go to Converter folder
   	$cd Converter
4) Run  p.py
	$python p.py
5) Check the output files in Output folder

----------------------  Author ----------------------  
Khine Shwe Zin 
shwezin.k@gmail.com
14 June 2019
------------------------------------------------------