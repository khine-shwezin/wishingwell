
    <?php
    function mylog2($data){
        echo 'console.log(from note summary logging);';
        echo 'console.log('. json_encode( $data ) .');';
    }

    $newDataXml= file_get_contents('php://input');
    $fh = fopen('noteData.xml','w+');
    mylog2("noteSummary....");
    mylog2($newDataXml);
    fwrite($fh, $newDataXml);
    fclose($fh);
    //clearstatcache();
    mylog2("Saved in PHP. Cleared Cache");
    ?>


