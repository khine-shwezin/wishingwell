<html>
<head><link rel="stylesheet" type="text/css" href="Css/UICSS.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head> 

<body onload="bodyOnLoad()">
<form action="Note.php" method="POST" enctype="multipart/form-data" name="EWSNoteForm" onload="formOnLoad()">
<table>
	<tr>
	<div class="textcss">
	<label >Select the note: </label>
            <select id="noteId" name="noteId" onchange="onChange()" class="mediumtextcss"/>
                <option value="todoId">To Do</option>
                <option value="ewsId">EWS</option>
                <option value="techlinuxId">Linux and Shell</option>
                <option value="techjsId">Javascript and Web</option>
                <option value="techphpId">PHP</option>
                <option value="techotherId">Tech Others</option>
                <option value="aobId">AOB</option>
                <option value="diaryId">Diary</option>
            </select>
	</div>
	</tr>
	<tr border=2>
		<td border=1>
			<div>
			<textarea name="noteArea" id="noteArea" placeholder="Write your note here" cols="80" rows="30"></textarea>
			</div>
		</td>
		<td border=1> 
			<div><input type="button" value="Load" name="edit" class="buttoncss" onclick="loadClick()"/></div>
			<div><input type="button" value="Save" id="saveBtn" name="save" onClick="submitClick()" class="buttoncss"/></div>
			<div><input type="button" value="Print" name="print" onCLick="printClick()" class="buttoncss"/>	</div>	
		</td>
	</tr>

</table>

</form> 

<script language="JavaScript" type="text/JavaScript">
function onChange(){
	console.log("onchange");
		document.getElementById("noteArea").value = "";
		loadClick();
}

function submitClick(){

    var formNoteAreaVal = document.getElementById("noteArea").value;
    var formNoteId = document.getElementById("noteId").value;
    var formNoteDate= new Date();
    var mydom;
    console.log("[Submit Click to reload] Note to save : "+formNoteAreaVal+", noteId:"+formNoteId);
 

    var xmlhttp;
    if(window.XMLHttpRequest){
      console.log("NEW xmlHTTPReuest General");
         xmlhttp = new XMLHttpRequest();
    }else if(window.ActiveXObject){
            console.log("NEW xmlHTTPReuest Microsoft");
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.responseType = 'document';
    xmlhttp.overrideMimeType('text/xml');
    xmlhttp.onreadystatechange = function() {
       if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			    var xml, xmlDoc, allNodes;
			    xml = xmlhttp.responseXML;
          console.log("responseXML::"+xml.documentElement.toSource());
          console.log("response:"+xmlhttp.response.toSource());
			    xmlDoc = xml.documentElement;
			    allNodes = xmlDoc.getElementsByTagName("Note");
			    var len = allNodes.length;
          console.log("Length of all nodes:"+len);
			    var pNode = allNodes[1].parentNode;
			    var idx;
			     filterElementNodes(pNode);
			     idx = findIdx(pNode,formNoteId);
			     removeNoteNode(xmlDoc, idx);

	             var newRootEle = xml.createElement("Note");
	             var newele1 = xml.createElement("Id");
                 var newtext1 = xml.createTextNode(formNoteId);
                 newele1.appendChild(newtext1);
                 newRootEle.appendChild(newele1);
                 
                 newele2 = xml.createElement("Name");
                 newtext2 = xml.createTextNode(formNoteId);
                 newele2.appendChild(newtext2);
                 newRootEle.appendChild(newele2);
                 
                 newele3 = xml.createElement("Date");
                 newtext3 = xml.createTextNode(formNoteDate);
                 newele3.appendChild(newtext3);
                 newRootEle.appendChild(newele3);
                 
                 newele4 = xml.createElement("Data");
                 newtext4 = xml.createTextNode(formNoteAreaVal);
                 newele4.appendChild(newtext4);
                 newRootEle.appendChild(newele4);
                 
                 x = xml.getElementsByTagName("Note");
                 x[0].parentNode.appendChild(newRootEle);
	        	 saveData(xmlDoc);
	             
		   }
        };
    xmlhttp.open("GET", "noteData.xml", true);
    xmlhttp.send();

}

function saveData(xml){
	var s = new XMLSerializer();
	var d = xml;
	var str = s.serializeToString(d);
	
	$.ajax({
	    url: "noteSummary.php",
	    data: str,
	    type: 'POST',
	    contentType: "text/xml",
	    dataType: "text",
	    success : function(){
	        console.log("Save Successful!");
	           document.getElementById("noteArea").value = "";
             window.location.reload(true);
	    },
	    error : function (xhr, ajaxOptions, thrownError){  
	        console.log(xhr.status);          
	        console.log(thrownError);
	    } 
	});
}
function removeNoteNode(xmlDoc,idx){
		y = xmlDoc.getElementsByTagName("Note")[idx];
		xmlDoc.removeChild(y);

}
function findIdx( pNode, formNoteId){
		var parentLen = pNode.childNodes.length; 
		for(var i=0; i < parentLen ;i++){
			var node =  pNode.childNodes[i];
			filterElementNodes(node);
			if(node.childNodes[0].childNodes[0].nodeValue == formNoteId){
				idx = i;
			}
		}
	return idx;
}
function filterElementNodes(parentNode){
	var len = parentNode.childNodes.length;
	for(var i=0 ; i< len ; i++){
		var cnode = parentNode.childNodes[i];
		if( cnode!=null && cnode.nodeType != 1){
			cnode.parentNode.removeChild(cnode);
		}
	}
}

function loadClick(){

    var formNoteAreaVal = document.getElementById("noteArea").value;
    var formNoteId = document.getElementById("noteId").value;
    console.log("[loadClick] formNoteId:"+formNoteId);

    var xmlhttp;
    if(window.XMLHttpRequest){
         xmlhttp = new XMLHttpRequest();
    }else if(window.ActiveXObject){
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
			    var xml, xmlDoc, allNodes;
			    console.log("this:"+this);
			    xml = this.responseXML;
			    if(!xml){
			    console.log("xml is NULL");
				    if(window.ActiveXObject){
				       xml=new ActiveXObject('Microsoft.XMLDOM');
				       xml.async = false;
				       xml.loadXML(xhttp.responseText);
				    }else{
				        xml= (new DOMParser()).parseFromString(xhttp.responseText, 'text/xml');
				        console.log("xml:"+xml.toSource());
				    }
			    }
			    xmlDoc = xml.documentElement;
			    allNodes = xmlDoc.getElementsByTagName("Note");
			    var len = allNodes.length;
			    var pNode = allNodes[1].parentNode;
			    var idx;
			     filterElementNodes(pNode);
			     idx = findIdx(pNode,formNoteId);
			     var node = xmlDoc.getElementsByTagName("Note")[idx];
			     filterElementNodes(node);
			     var nodeText = node.childNodes[3].childNodes[0].nodeValue;
			     document.getElementById("noteArea").value = nodeText;
			}
        };
    xmlhttp.open("GET", "noteData.xml?date="+new Date(), true);
    xmlhttp.send();
} // loadClick ends

function bodyOnLoad(){

    document.getElementById("noteArea").value="";
    document.getElementById("noteId").value="ewsNote";

    <?php
    function mylog($data){
        echo 'console.log('. json_encode( $data ) .');';
    }
    $newDataXml= file_get_contents('php://input');
    $fh = fopen('noteData.xml','r+');
    mylog($newDataXml);
    mylog($fh);
    fwrite($fh, $newDataXml);
    fclose($fh);
    ?>
}
</script> 
</body>
</html>
