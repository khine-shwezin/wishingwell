<html>
<head><link rel="stylesheet" type="text/css" href="Css/UICSS.css" /></head> 
<body>

<table class="mainTablecss" >

<tr height="100" >
<td width="15%"  class="sidePanelcss" rowspan="4" ></td>
<td width="70%" background="" align="center">
<h2 class="textTitlecss">Wishing Well</h2>

<div class="textcss">Note Hub</div>
</td>

<td width="15%" class="sidePanelcss" rowspan="4" ></td>
</tr>

<tr height="30">
<td width="70%" align="center" background="">
<a href="Note.php" target="data" class="smalltextcss">Note</a>
<a href="about.txt" target="data" class="smalltextcss">About</a>

</tr>
<tr height="550">
<td width="70%" align="center">

<iframe name="data" width="1400" height="900" frameBorder="0" src="Note.php"></iframe>

</td>

</tr>

<tr height="30">
<td width="800" class="textcss" align="center">Thank you</td> 
</tr>

</table>
</body>

</html>

